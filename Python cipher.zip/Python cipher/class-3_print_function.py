# print function
# stdin
# stdout
# stderr

print("python programming")

print(1,2,3,"functions" , 1+2j,2.23,sep=",")
# sep used to seprate with commas

print("hello",end=";")
print("world")

print("a",end=")")
print("b",end=")")
print("c")