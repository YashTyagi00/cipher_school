print("Hello world")

# This is a comments

'''my
name 
is'''

# every line executed in python is either a statement or expression 

"programming language"
print("Hello")

# data types:-
# integers
# float
# string
# complex

# a="a"
# print(type(a))

# b=2
# print(type(b))

print(isinstance('a',str))
print(isinstance(2,int))
print(isinstance(print,object))
print(isinstance('b',int))


a="python"
print(a)

b=2222
print(b)

# id function determine the ram address

print(id(a))
print(id(b))

#variables

_a="rom"









