# input function
# a=input()
# print(a)
# print(type(a))

#typecoercion to change to your domain  level

# b=15
# print(str(b))

a="a"
print(isinstance(a,object))
