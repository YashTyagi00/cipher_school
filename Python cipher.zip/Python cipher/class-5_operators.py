# operators

# arithemetic operators

print(8+8)
print(65/5)
print(10/3)
print(10//3)

# assignment operators
a=55
a+=7
print(a)

# comparison operators

b=(14<7)
print(b)

#logical operators
bool1=True
bool2=False
print("The value of bool1 and bool2 is",(bool1 and bool2))
print("The value of bool1 and bool2 is",(bool1 or bool2))
print("The value of bool1 and bool2 is",(not bool2))